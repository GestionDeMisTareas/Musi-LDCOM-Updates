@echo off
rem Lanzador auxiliar. Para cero consola visible, abrir Musi_LDCOM.vbs.
wscript.exe "%~dp0Musi_LDCOM.vbs"
exit /b
