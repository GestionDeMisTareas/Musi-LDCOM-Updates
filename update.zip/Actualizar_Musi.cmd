@echo off
setlocal EnableExtensions
set "APP=%~dp0"
set "ZIP=%APP%update_download.zip"
set "STAGE=%APP%_update_stage"
set "LOG=%APP%update_error.txt"

echo [%date% %time%] Actualizador iniciado> "%LOG%"
timeout /t 5 /nobreak >nul

if not exist "%ZIP%" (
  echo No existe update_download.zip>>"%LOG%"
  exit /b 10
)

if exist "%STAGE%" rmdir /s /q "%STAGE%" >nul 2>&1
mkdir "%STAGE%" >nul 2>&1

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; Expand-Archive -LiteralPath '%ZIP%' -DestinationPath '%STAGE%' -Force" >>"%LOG%" 2>&1
if errorlevel 1 (
  echo Error al extraer la actualización.>>"%LOG%"
  exit /b 20
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$i=@(Get-ChildItem -LiteralPath '%STAGE%' -Force); if($i.Count -eq 1 -and $i[0].PSIsContainer){$s=$i[0].FullName}else{$s='%STAGE%'}; Get-ChildItem -LiteralPath $s -Force | ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination '%APP%' -Recurse -Force }" >>"%LOG%" 2>&1
if errorlevel 1 (
  echo Error al reemplazar los archivos.>>"%LOG%"
  exit /b 30
)

rmdir /s /q "%STAGE%" >nul 2>&1
del /q "%ZIP%" >nul 2>&1

echo [%date% %time%] Actualización instalada.>>"%LOG%"

if exist "%APP%Iniciar_Musi_LDCOM.vbs" (
  start "" wscript.exe //B "%APP%Iniciar_Musi_LDCOM.vbs"
) else if exist "%APP%LDCOM_Portable.ps1" (
  start "" powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%APP%LDCOM_Portable.ps1"
)

rem Se conserva Actualizar_Musi.cmd para futuras actualizaciones.
exit /b 0
