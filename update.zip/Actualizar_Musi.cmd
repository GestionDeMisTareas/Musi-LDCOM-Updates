@echo off
setlocal EnableExtensions
set "MUSI_UPDATE_APP_DIR=%~dp0"
set "MUSI_UPDATE_ZIP=%~dp0update_download.zip"
set "MUSI_UPDATE_STAGE=%~dp0_update_stage"
set "MUSI_UPDATE_LOG=%~dp0update_error.txt"
timeout /t 5 /nobreak >nul
if not exist "%MUSI_UPDATE_ZIP%" exit /b 10
echo Actualizando Musi LDCOM>"%MUSI_UPDATE_LOG%"
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; if(Test-Path -LiteralPath $env:MUSI_UPDATE_STAGE){Remove-Item -LiteralPath $env:MUSI_UPDATE_STAGE -Recurse -Force}; Expand-Archive -LiteralPath $env:MUSI_UPDATE_ZIP -DestinationPath $env:MUSI_UPDATE_STAGE -Force; $items=@(Get-ChildItem -LiteralPath $env:MUSI_UPDATE_STAGE -Force); $source=$env:MUSI_UPDATE_STAGE; if($items.Count -eq 1 -and $items[0].PSIsContainer){$source=$items[0].FullName}; Get-ChildItem -LiteralPath $source -Force | ForEach-Object {Copy-Item -LiteralPath $_.FullName -Destination $env:MUSI_UPDATE_APP_DIR -Recurse -Force}" >>"%MUSI_UPDATE_LOG%" 2>&1
if errorlevel 1 exit /b 20
rmdir /s /q "%MUSI_UPDATE_STAGE%" >nul 2>&1
del /q "%MUSI_UPDATE_ZIP%" >nul 2>&1
del /q "%MUSI_UPDATE_LOG%" >nul 2>&1
start "" wscript.exe //B "%MUSI_UPDATE_APP_DIR%Iniciar_Musi_LDCOM.vbs"
exit /b 0
