@echo off
title Diagnostico Musi LDCOM
cd /d "%~dp0"
echo Iniciando diagnostico...
echo.
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0LDCOM_Portable.ps1"
echo.
echo Codigo de salida: %errorlevel%
pause
