Option Explicit
Dim sh, fso, app, target
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
app = fso.GetParentFolderName(WScript.ScriptFullName)
target = fso.BuildPath(app, "Musi_LDCOM.vbs")
If Not fso.FileExists(target) Then
  MsgBox "No se encontró Musi_LDCOM.vbs.", 16, "Musi LDCOM"
  WScript.Quit 2
End If
sh.Run Chr(34) & target & Chr(34), 0, False
