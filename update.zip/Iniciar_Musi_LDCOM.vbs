Option Explicit
Dim sh, fso, app, ps1, psExe, args, shellApp
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
app = fso.GetParentFolderName(WScript.ScriptFullName)
ps1 = fso.BuildPath(app, "LDCOM_Portable.ps1")
psExe = sh.ExpandEnvironmentStrings("%SystemRoot%") & "\System32\WindowsPowerShell\v1.0\powershell.exe"
If Not fso.FileExists(ps1) Then MsgBox "No se encontró LDCOM_Portable.ps1.",16,"Musi LDCOM": WScript.Quit 2
args = "-NoProfile -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File " & Chr(34) & ps1 & Chr(34)
Set shellApp = CreateObject("Shell.Application")
shellApp.ShellExecute psExe, args, app, "runas", 0
