﻿Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName Microsoft.VisualBasic
$ErrorActionPreference = "Stop"
$AppVersion = "24.4.0"
$VersionFile = Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) "version.txt"
if(Test-Path $VersionFile){ try { $vf=(Get-Content $VersionFile -Raw).Trim(); if($vf -match "^(\d+(?:\.\d+){1,3})"){$AppVersion=$Matches[1]} } catch {} }
$IsAdmin = ($args -contains "-Admin")
$DefaultUpdateSource = "https://raw.githubusercontent.com/MusiLaFortuna/Musi-LDCOM-Updates/main"

Add-Type @"
using System;
using System.Runtime.InteropServices;
public static class Win32 {
  [DllImport("user32.dll")] public static extern bool SetCursorPos(int X, int Y);
  [DllImport("user32.dll")] public static extern void mouse_event(uint flags, uint dx, uint dy, uint data, UIntPtr extraInfo);
  [DllImport("user32.dll")] public static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, UIntPtr dwExtraInfo);
}
"@

trap {
  try {
    Add-Type -AssemblyName System.Windows.Forms -ErrorAction SilentlyContinue
    [Windows.Forms.MessageBox]::Show((($_ | Out-String).Trim()), "Musi LDCOM - Error") | Out-Null
  } catch {}
  exit 1
}

[System.Windows.Forms.Application]::EnableVisualStyles()
[System.Windows.Forms.Application]::SetCompatibleTextRenderingDefault($false)

$AppDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$DataFile = Join-Path $AppDir "ldcom_data.json"
$ClientPrefsFile = Join-Path $AppDir "client_prefs.json"
$ClientCatalogFile = Join-Path $AppDir "client_catalog.json"
$ImageDir = Join-Path $AppDir "images"
if (!(Test-Path $ImageDir)) { New-Item -ItemType Directory $ImageDir | Out-Null }

function A($x) { if($null -eq $x){ return @() }; return @($x) }
function Save-Data($d) { $d | ConvertTo-Json -Depth 50 | Set-Content $DataFile -Encoding UTF8 }
function Save-ClientCatalog($d) { $d | ConvertTo-Json -Depth 50 | Set-Content $ClientCatalogFile -Encoding UTF8 }
function New-DefaultData {
  $json = @'
{
  "settings": {"targetX":0,"targetY":0,"hasTarget":false,"sendEnter":true,"clickSearch":true,"delayMs":80,"imageWidth":150,"imageHeight":150,"cardWidth":210,"cardHeight":255,"updateSource":""},
  "categories": [
    {"name":"Bebidas","icon":"♜","products":[{"name":"Coca Cola 500 ml","code":"100001","image":""},{"name":"Pepsi 355 ml","code":"100002","image":""},{"name":"Agua Cristal 600 ml","code":"100003","image":""},{"name":"Gatorade 500 ml","code":"100004","image":""},{"name":"Del Valle 500 ml","code":"100005","image":""}]},
    {"name":"Panadería","icon":"♨","products":[{"name":"Pan Bimbo Blanco","code":"200001","image":""},{"name":"Pan Bimbo Integral","code":"200002","image":""},{"name":"Pan Dulce Conchas","code":"200003","image":""},{"name":"Pan de molde","code":"200004","image":""}]},
    {"name":"Snacks","icon":"◉","products":[{"name":"Doritos Nacho","code":"300001","image":""},{"name":"Sabritas Original","code":"300002","image":""}]},
    {"name":"Lácteos","icon":"♙","products":[{"name":"Leche Dos Pinos 1L","code":"400001","image":""},{"name":"Queso Turrialba 500 g","code":"400002","image":""}]},
    {"name":"Frutas","icon":"●","products":[{"name":"Banano","code":"500001","image":""},{"name":"Manzana Roja","code":"500002","image":""},{"name":"Papa","code":"500003","image":""}]},
    {"name":"Congelados","icon":"❄","products":[]},
    {"name":"Limpieza","icon":"♙","products":[]},
    {"name":"Otros","icon":"•••","products":[]}
  ]
}
'@
  return ($json | ConvertFrom-Json)
}
function Load-Data {
  if(Test-Path $DataFile) {
    try {
      $d=Get-Content $DataFile -Raw | ConvertFrom-Json
      if($null -eq $d.settings){$d.settings=[PSCustomObject]@{}}
      foreach($kv in @(@('imageWidth',150),@('imageHeight',150),@('cardWidth',210),@('cardHeight',255),@('clickSearch',$true),@('sendEnter',$true),@('delayMs',80),@('hasTarget',$false),@('targetX',0),@('targetY',0))){ if($null -eq $d.settings.($kv[0])){$d.settings | Add-Member -NotePropertyName $kv[0] -NotePropertyValue $kv[1]} }
      foreach($c in (A $d.categories)){ if($null -eq $c.products){$c.products=@()}; if($null -eq $c.icon){$c | Add-Member -NotePropertyName icon -NotePropertyValue "●"}; if($null -eq $c.hidden){$c | Add-Member -NotePropertyName hidden -NotePropertyValue $false} }
      return $d
    } catch {}
  }
  $d=New-DefaultData; Save-Data $d; return $d
}
$data=Load-Data
if(-not $IsAdmin -and (Test-Path $ClientCatalogFile)) {
  try {
    $localCatalog=Get-Content $ClientCatalogFile -Raw | ConvertFrom-Json
    if($localCatalog -and $localCatalog.categories){ $data=$localCatalog }
  } catch {}
}

function Get-CategoryHidden($c) {
  if($null -eq $c.hidden){ return $false }
  return [bool]$c.hidden
}
function Get-VisibleCategories {
  $hidden=@()
  if(-not $IsAdmin -and (Test-Path $ClientPrefsFile)){
    try { $tmp=Get-Content $ClientPrefsFile -Raw | ConvertFrom-Json; if($null -ne $tmp.hiddenCategories){$hidden=@($tmp.hiddenCategories | ForEach-Object {[string]$_})} } catch {}
  }
  $out=@()
  foreach($c in (A $data.categories)){
    if((Get-CategoryHidden $c)){ continue }
    if($hidden -contains [string]$c.name){ continue }
    $out += $c
  }
  return @($out)
}
function Load-ClientPrefs {
  if(Test-Path $ClientPrefsFile){ try { return Get-Content $ClientPrefsFile -Raw | ConvertFrom-Json } catch {} }
  return [PSCustomObject]@{hiddenCategories=@()}
}
function Save-ClientPrefs($p) { $p | ConvertTo-Json -Depth 10 | Set-Content $ClientPrefsFile -Encoding UTF8 }

$LocalSettingsFile = Join-Path $AppDir "client_local.json"
function Load-LocalSettings {
  if(Test-Path $LocalSettingsFile){ try { return Get-Content $LocalSettingsFile -Raw | ConvertFrom-Json } catch {} }
  $s=[PSCustomObject]@{targetX=0;targetY=0;hasTarget=$false;clickSearch=$true;sendEnter=$true;delayMs=80;updateSource=""}
  try { $s | ConvertTo-Json -Depth 10 | Set-Content $LocalSettingsFile -Encoding UTF8 } catch {}
  return $s
}
function Save-LocalSettings($s) { $s | ConvertTo-Json -Depth 10 | Set-Content $LocalSettingsFile -Encoding UTF8 }
$localSettings=Load-LocalSettings
if(-not $IsAdmin -and [string]::IsNullOrWhiteSpace([string]$localSettings.updateSource)){ $localSettings.updateSource=$DefaultUpdateSource }
if(-not $IsAdmin){
  if($localSettings.hasTarget -eq $false -and $data.settings.hasTarget){
    $localSettings.targetX=$data.settings.targetX; $localSettings.targetY=$data.settings.targetY; $localSettings.hasTarget=$data.settings.hasTarget
    $localSettings.clickSearch=$data.settings.clickSearch; $localSettings.sendEnter=$data.settings.sendEnter; $localSettings.delayMs=$data.settings.delayMs
  }
  if([string]::IsNullOrWhiteSpace([string]$localSettings.updateSource) -and $data.settings.updateSource){$localSettings.updateSource=[string]$data.settings.updateSource}
  Save-LocalSettings $localSettings
}
function Get-Setting($name,$default=$null) {
  if(-not $IsAdmin -and $null -ne $localSettings -and $null -ne $localSettings.PSObject.Properties[$name]) { return $localSettings.$name }
  if($null -ne $data.settings -and $null -ne $data.settings.PSObject.Properties[$name]) { return $data.settings.$name }
  return $default
}
function Set-Setting($name,$value) {
  if($IsAdmin){$data.settings.$name=$value;Save-Data $data}
  else {$localSettings.$name=$value;Save-LocalSettings $localSettings}
}
function Normalize-UpdateSource($source) { if($null -eq $source){return ""}; return ([string]$source).Trim().TrimEnd([char[]]('/\\')) }
function Get-ManifestFromSource($source) {
  $source=Normalize-UpdateSource $source
  if([string]::IsNullOrWhiteSpace($source)){throw "No hay un origen de actualización configurado."}
  if($source -match '^https?://') {
    # Descargar el JSON como texto y convertirlo explícitamente.
    # Esto evita que Windows PowerShell interprete de forma distinta la respuesta de GitHub.
    $url="$source/update_manifest.json"
    $resp=Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 20
    $raw=[string]$resp.Content
    if([string]::IsNullOrWhiteSpace($raw)){throw "GitHub devolvió un manifiesto vacío."}
    $raw=$raw.TrimStart([char]0xFEFF).Trim()
    $manifest=$raw | ConvertFrom-Json
    if($null -eq $manifest){throw "No se pudo leer update_manifest.json."}
    $version=[string]$manifest.version
    if([string]::IsNullOrWhiteSpace($version)){
      throw "El update_manifest.json descargado no contiene el campo 'version'."
    }
    return $manifest
  }
  $mf=Join-Path $source 'update_manifest.json'
  if(!(Test-Path $mf)){throw "No se encontró update_manifest.json en: $source"}
  $raw=Get-Content $mf -Raw
  $raw=$raw.TrimStart([char]0xFEFF).Trim()
  $manifest=$raw | ConvertFrom-Json
  if($null -eq $manifest){throw "No se pudo leer update_manifest.json."}
  return $manifest
}
function Download-UpdatePackage($source,$targetDir,$manifest=$null) {
  $source=Normalize-UpdateSource $source
  if([string]::IsNullOrWhiteSpace($source)){throw "No hay un origen de actualización configurado."}
  $zip=Join-Path $targetDir 'update_download.zip'
  $package='update.zip'
  if($null -ne $manifest -and -not [string]::IsNullOrWhiteSpace([string]$manifest.package)){
    $package=[string]$manifest.package
  }
  if($source -match '^https?://') {
    Invoke-WebRequest -Uri "$source/$package" -OutFile $zip -UseBasicParsing -TimeoutSec 120
  } else {
    Copy-Item -LiteralPath (Join-Path $source $package) -Destination $zip -Force
  }
  if(!(Test-Path -LiteralPath $zip)){throw "No se pudo descargar el paquete de actualización."}
  if((Get-Item -LiteralPath $zip).Length -lt 100){throw "El paquete de actualización descargado está vacío o incompleto."}
  return $zip
}
function Start-SelfUpdate($source,$manifest) {
  try {
    $app=[IO.Path]::GetFullPath($AppDir)
    $zip=Join-Path $app 'update_download.zip'
    Download-UpdatePackage $source $app $manifest | Out-Null
    if(!(Test-Path -LiteralPath $zip)){throw "No se descargó update_download.zip."}
    $updater=Join-Path $app 'Actualizar_Musi.cmd'
    if(!(Test-Path -LiteralPath $updater)){
      # Bootstrap para clientes antiguos: extraer el CMD desde update_download.zip.
      try{
        $boot=Join-Path $targetDir '_updater_bootstrap'
        if(Test-Path -LiteralPath $boot){Remove-Item -LiteralPath $boot -Recurse -Force -ErrorAction SilentlyContinue}
        New-Item -ItemType Directory -Path $boot -Force|Out-Null
        Expand-Archive -LiteralPath $zip -DestinationPath $boot -Force
        $candidate=Join-Path $boot 'Actualizar_Musi.cmd'
        if(!(Test-Path -LiteralPath $candidate)){
          $found=Get-ChildItem -LiteralPath $boot -Filter 'Actualizar_Musi.cmd' -File -Recurse -ErrorAction SilentlyContinue|Select-Object -First 1
          if($found){$candidate=$found.FullName}
        }
        if(Test-Path -LiteralPath $candidate){Copy-Item -LiteralPath $candidate -Destination $updater -Force}
        Remove-Item -LiteralPath $boot -Recurse -Force -ErrorAction SilentlyContinue
      }catch{}
    }
    if(!(Test-Path -LiteralPath $updater)){throw "No se encontró Actualizar_Musi.cmd en la actualización."}

    # CMD es independiente del proceso PowerShell que se está cerrando.
    Start-Process -FilePath 'cmd.exe' -ArgumentList @('/c',"`"$updater`"") -WorkingDirectory $app -WindowStyle Hidden
    Start-Sleep -Milliseconds 1000
    $panel.Close()
  } catch {
    [Windows.Forms.MessageBox]::Show("No se pudo iniciar la actualización.`n`n$($_.Exception.Message)","Actualizaciones",[Windows.Forms.MessageBoxButtons]::OK,[Windows.Forms.MessageBoxIcon]::Error)|Out-Null
  }
}
function Check-ForUpdates([bool]$interactive=$true) {
  try {
    $source="https://raw.githubusercontent.com/MusiLaFortuna/Musi-LDCOM-Updates/main"
    $m=Get-ManifestFromSource $source
    $remote=[string]$m.version
    $local=[string]$AppVersion
    if([string]::IsNullOrWhiteSpace($local)){ $local="0.0.0" }
    if([string]::IsNullOrWhiteSpace($remote)){ throw "El update_manifest.json no contiene una versión válida." }
    $remote=$remote.Trim(); $local=$local.Trim()
    try {
      $remoteVersion=[System.Version]$remote
      $localVersion=[System.Version]$local
    } catch {
      throw "La versión no es válida. Actual: '$local' | Disponible: '$remote'."
    }
    if($remoteVersion -le $localVersion){
      if($interactive){[Windows.Forms.MessageBox]::Show("Musi LDCOM ya está actualizado. Versión $local.","Actualizaciones")|Out-Null}
      return
    }
    $r=[Windows.Forms.MessageBox]::Show("Hay una actualización disponible: v$remote`nVersión actual: v$local`n`n¿Actualizar ahora?","Actualización disponible",[Windows.Forms.MessageBoxButtons]::YesNo,[Windows.Forms.MessageBoxIcon]::Information)
    if($r -eq [Windows.Forms.DialogResult]::Yes){Start-SelfUpdate $source $m}
  } catch {
    if($interactive){[Windows.Forms.MessageBox]::Show("No se pudo buscar la actualización.`n`n$($_.Exception.Message)","Actualizaciones",[Windows.Forms.MessageBoxButtons]::OK,[Windows.Forms.MessageBoxIcon]::Error)|Out-Null}
  }
}
function Publish-Update($destination,$newVersion) {
  $destination=Normalize-UpdateSource $destination
  if([string]::IsNullOrWhiteSpace($destination)){throw "Selecciona una carpeta de publicación."}
  if(!(Test-Path $destination)){New-Item -ItemType Directory -Path $destination -Force | Out-Null}
  $stage=Join-Path ([IO.Path]::GetTempPath()) ("MusiPublish_"+[guid]::NewGuid().ToString('N')); New-Item -ItemType Directory -Path $stage -Force | Out-Null
  try {
    Get-ChildItem -LiteralPath $AppDir -Force | Where-Object { $_.Name -notin @('client_prefs.json','client_local.json','update.zip','update_manifest.json') } | ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination $stage -Recurse -Force }
    $ps=Join-Path $stage 'LDCOM_Portable.ps1'; if(Test-Path $ps){$txt=Get-Content $ps -Raw; $txt=[regex]::Replace($txt,'\$AppVersion\s*=\s*"[^"]*"','$AppVersion = "24.4.0"',1); Set-Content $ps $txt -Encoding UTF8}
    Set-Content (Join-Path $stage 'version.txt') "$newVersion - MUSI LDCOM" -Encoding UTF8
    $zip=Join-Path $destination 'update.zip'; if(Test-Path $zip){Remove-Item $zip -Force}
    Compress-Archive -Path (Join-Path $stage '*') -DestinationPath $zip -Force
    $manifest=[PSCustomObject]@{version=$newVersion;package='update.zip';published=(Get-Date).ToString('s')}
    $manifest | ConvertTo-Json | Set-Content (Join-Path $destination 'update_manifest.json') -Encoding UTF8
  } finally { Remove-Item $stage -Recurse -Force -ErrorAction SilentlyContinue }
}


function Load-ImageSafe($path) {
  if([string]::IsNullOrWhiteSpace($path)){ return $null }
  $full=Join-Path $AppDir $path
  if(!(Test-Path $full)){ return $null }
  try {
    $fs=[IO.File]::Open($full,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::ReadWrite)
    try { $img=[Drawing.Image]::FromStream($fs); return New-Object Drawing.Bitmap($img) } finally { $fs.Dispose() }
  } catch { return $null }
}

function Click-At($x,$y) {
  [Win32]::SetCursorPos([int]$x,[int]$y) | Out-Null
  Start-Sleep -Milliseconds 80
  [Win32]::mouse_event(0x0002,0,0,0,[UIntPtr]::Zero)
  Start-Sleep -Milliseconds 30
  [Win32]::mouse_event(0x0004,0,0,0,[UIntPtr]::Zero)
}
function Key-Down([byte]$vk) { [Win32]::keybd_event($vk,0,0,[UIntPtr]::Zero) }
function Key-Up([byte]$vk) { [Win32]::keybd_event($vk,0,0x0002,[UIntPtr]::Zero) }
function Key-Combo([byte]$modifier,[byte]$key) {
  Key-Down $modifier; Start-Sleep -Milliseconds 15; Key-Down $key; Start-Sleep -Milliseconds 15; Key-Up $key; Key-Up $modifier
}
function Send-Code($code) {
  if([string]::IsNullOrWhiteSpace($code)){return}
  try {
    # Ocultar Musi para que LDCOM quede como ventana activa.
    $panel.Hide()
    Start-Sleep -Milliseconds 180

    if([bool](Get-Setting "clickSearch" $true) -and [bool](Get-Setting "hasTarget" $false)) {
      Click-At (Get-Setting "targetX" 0) (Get-Setting "targetY" 0)
      Start-Sleep -Milliseconds ([Math]::Max(150,[int](Get-Setting "delayMs" 80)))
      # Ctrl+A mediante Win32 evita las limitaciones de SendKeys entre aplicaciones.
      Key-Combo 0x11 0x41
      Start-Sleep -Milliseconds 60
    }

    [System.Windows.Forms.Clipboard]::SetText([string]$code)
    Start-Sleep -Milliseconds 50
    # Ctrl+V mediante Win32.
    Key-Combo 0x11 0x56

    if($(Get-Setting "sendEnter" $true)){
      Start-Sleep -Milliseconds 100
      Key-Down 0x0D; Start-Sleep -Milliseconds 20; Key-Up 0x0D
    }
    Start-Sleep -Milliseconds 180
  } finally {
    $panel.Show()
    $panel.Activate()
  }
}

# ---------------- Musi LDCOM - ventana vertical compacta ----------------
$panel=New-Object Windows.Forms.Form
$panel.Text="Musi LDCOM"
$panel.FormBorderStyle="FixedSingle"
$panel.MinimizeBox=$true; $panel.MaximizeBox=$false
$panel.StartPosition="CenterScreen"
$panel.ClientSize=New-Object Drawing.Size(460,800)
$panel.BackColor=[Drawing.Color]::FromArgb(246,247,249)

$header=New-Object Windows.Forms.Panel; $header.Dock="Top"; $header.Height=64; $header.BackColor=[Drawing.Color]::FromArgb(225,12,20); $panel.Controls.Add($header)
$logo=New-Object Windows.Forms.PictureBox; $logo.Image=[Drawing.Image]::FromFile((Join-Path $AppDir "images\musi_logo.png")); $logo.SizeMode="Zoom"; $logo.Width=112; $logo.Height=54; $logo.Location=New-Object Drawing.Point(10,5); $logo.BackColor=[Drawing.Color]::FromArgb(225,12,20); $header.Controls.Add($logo)
$gear=New-Object Windows.Forms.PictureBox; $gear.Width=30; $gear.Height=30; $gear.Location=New-Object Drawing.Point(416,17); $gear.BackColor=[Drawing.Color]::FromArgb(255,206,0); $gear.SizeMode="Zoom"; $gear.Cursor=[Windows.Forms.Cursors]::Hand
try {$gear.Image=[Drawing.Image]::FromFile((Join-Path $AppDir "images\configuracion.png"))} catch {}
$header.Controls.Add($gear)
$updateBtn=New-Object Windows.Forms.Button; $updateBtn.Text="↻"; $updateBtn.Width=34; $updateBtn.Height=30; $updateBtn.Location=New-Object Drawing.Point(376,17); $updateBtn.FlatStyle="Flat"; $updateBtn.Font=New-Object Drawing.Font("Segoe UI",12,[Drawing.FontStyle]::Bold); $updateBtn.Cursor=[Windows.Forms.Cursors]::Hand; $updateBtn.TabStop=$false; $updateBtn.TextAlign="MiddleCenter"; $updateBtn.BackColor=[Drawing.Color]::FromArgb(255,206,0); $updateBtn.ForeColor=[Drawing.Color]::FromArgb(30,30,30); $updateBtn.FlatAppearance.BorderSize=0; $updateBtn.Visible=(-not $IsAdmin); $updateBtn.Add_Click({Check-ForUpdates $true}); $header.Controls.Add($updateBtn)
$mainCash=New-Object Windows.Forms.Button; $mainCash.Text="₡"; $mainCash.Width=34; $mainCash.Height=30
$mainCash.Location=New-Object Drawing.Point(334,17); $mainCash.FlatStyle="Flat"
$mainCash.Font=New-Object Drawing.Font("Segoe UI",12,[Drawing.FontStyle]::Bold)
$mainCash.BackColor=[Drawing.Color]::FromArgb(255,206,0); $mainCash.ForeColor=[Drawing.Color]::FromArgb(30,30,30); $mainCash.FlatAppearance.BorderSize=0
$mainCash.Cursor=[Windows.Forms.Cursors]::Hand; $mainCash.TabStop=$false
$mainCash.Add_Click({Show-CashCounter}); $header.Controls.Add($mainCash)


$main=New-Object Windows.Forms.Panel; $main.Dock="Fill"; $main.BackColor=[Drawing.Color]::FromArgb(246,247,249); $panel.Controls.Add($main)
$search=New-Object Windows.Forms.TextBox; $search.Text="Buscar producto..."; $search.ForeColor=[Drawing.Color]::Gray; $search.Font=New-Object Drawing.Font("Segoe UI",9.5); $search.Width=420; $search.Height=28; $search.Location=New-Object Drawing.Point(12,10); $main.Controls.Add($search)
$search.Add_GotFocus({if($search.Text -eq "Buscar producto..."){$search.Text="";$search.ForeColor=[Drawing.Color]::Black}})
$search.Add_LostFocus({if([string]::IsNullOrWhiteSpace($search.Text)){$search.Text="Buscar producto...";$search.ForeColor=[Drawing.Color]::Gray}})

# Sección de categorías: desplazamiento ÚNICAMENTE horizontal.
# El panel interno crece según el nombre completo de cada categoría y nunca corta el texto.
$categoryViewport=New-Object Windows.Forms.Panel
$categoryViewport.Location=New-Object Drawing.Point(8,64)
$categoryViewport.Anchor="Top,Left,Right"
$categoryViewport.Width=444
$categoryViewport.Height=42
$categoryViewport.AutoScroll=$false
$categoryViewport.BackColor=[Drawing.Color]::FromArgb(246,247,249)
$categoryViewport.BorderStyle="None"
$main.Controls.Add($categoryViewport)

$categoryFlow=New-Object Windows.Forms.FlowLayoutPanel
$categoryFlow.Location=New-Object Drawing.Point(0,0)
$categoryFlow.AutoSize=$true
$categoryFlow.AutoSizeMode="GrowAndShrink"
$categoryFlow.Height=42
$categoryFlow.WrapContents=$false
$categoryFlow.FlowDirection="LeftToRight"
$categoryFlow.BackColor=[Drawing.Color]::FromArgb(246,247,249)
$categoryFlow.Padding=New-Object Windows.Forms.Padding(2,2,2,2)
$categoryViewport.Controls.Add($categoryFlow)

$categoryHScroll=New-Object Windows.Forms.HScrollBar
$categoryHScroll.Location=New-Object Drawing.Point(8,106)
$categoryHScroll.Anchor="Top,Left,Right"
$categoryHScroll.Width=444
$categoryHScroll.Height=17
$categoryHScroll.Minimum=0
$categoryHScroll.SmallChange=40
$categoryHScroll.LargeChange=454
$categoryHScroll.TabStop=$false
$main.Controls.Add($categoryHScroll)

$productSearch=New-Object Windows.Forms.TextBox; $productSearch.Text="Buscar en esta categoría..."; $productSearch.ForeColor=[Drawing.Color]::Gray; $productSearch.Font=New-Object Drawing.Font("Segoe UI",9.5); $productSearch.Width=420; $productSearch.Height=28; $productSearch.Location=New-Object Drawing.Point(12,127); $main.Controls.Add($productSearch)
$productSearch.Add_GotFocus({if($productSearch.Text -eq "Buscar en esta categoría..."){$productSearch.Text="";$productSearch.ForeColor=[Drawing.Color]::Black}})
$productSearch.Add_LostFocus({if([string]::IsNullOrWhiteSpace($productSearch.Text)){$productSearch.Text="Buscar en esta categoría...";$productSearch.ForeColor=[Drawing.Color]::Gray}})

$productPanel=New-Object Windows.Forms.FlowLayoutPanel; $productPanel.Location=New-Object Drawing.Point(8,162); $productPanel.Anchor="Top,Bottom,Left,Right"; $productPanel.Width=444; $productPanel.Height=630; $productPanel.AutoScroll=$true; $productPanel.BackColor=[Drawing.Color]::FromArgb(246,247,249); $productPanel.Padding=New-Object Windows.Forms.Padding(4); $productPanel.WrapContents=$true; $productPanel.FlowDirection="LeftToRight"; $main.Controls.Add($productPanel)
$status=New-Object Windows.Forms.Label; $status.Dock="Bottom"; $status.Height=34; $status.Text="   ● Conectado a LDCOM"; $status.Font=New-Object Drawing.Font("Segoe UI",8.5,[Drawing.FontStyle]::Bold); $status.BackColor=[Drawing.Color]::FromArgb(225,12,20); $status.ForeColor=[Drawing.Color]::White; $status.TextAlign="MiddleLeft"; $panel.Controls.Add($status)
$author=New-Object Windows.Forms.Label; $author.Text="v$AppVersion  •  Hecho por Enmanuel Guevara Valerio"; $author.AutoSize=$true; $author.Font=New-Object Drawing.Font("Segoe UI",7.5,[Drawing.FontStyle]::Bold); $author.ForeColor=[Drawing.Color]::FromArgb(255,215,0); $author.BackColor=[Drawing.Color]::FromArgb(225,12,20); $author.Anchor="Bottom,Right"; $author.Location=New-Object Drawing.Point(222,778); $author.BringToFront(); $panel.Controls.Add($author)

$script:selectedCategory=$null
$script:categoryButtons=@()
$script:productCards=@()
$script:selectedProductIndex=0

function Get-SearchText { if($productSearch.Text -eq "Buscar en esta categoría..."){return ""}; return $productSearch.Text.Trim().ToLower() }
function Show-Products($c) {
  $script:selectedCategory=$c
  $script:selectedProductIndex=0
  $productPanel.SuspendLayout(); $productPanel.Controls.Clear(); $script:productCards=@()
  $filter=Get-SearchText; $items=@()
  foreach($p in (A $c.products)){
    if($filter -and (-not ([string]$p.name).ToLower().Contains($filter)) -and (-not ([string]$p.code).ToLower().Contains($filter))){continue}
    $items += $p
  }
  $script:currentProductItems=@($items)
  foreach($p in $items){
    # Reserva siempre el ancho de la barra vertical y los márgenes para garantizar 3 columnas.
    $reservedWidth=[Windows.Forms.SystemInformation]::VerticalScrollBarWidth + $productPanel.Padding.Horizontal + 30
    $availableWidth=[Math]::Max(390,[int]$productPanel.ClientSize.Width-$reservedWidth)
    $cardWidth=[Math]::Max(124,[Math]::Min(132,[int]($availableWidth/3)))
    $card=New-Object Windows.Forms.Panel
    $card.Width=$cardWidth; $card.Height=178; $card.BackColor=[Drawing.Color]::White; $card.BorderStyle="FixedSingle"; $card.Cursor=[Windows.Forms.Cursors]::Hand; $card.Margin=New-Object Windows.Forms.Padding(4); $card.Tag=$p; $card.TabStop=$true
    $picSize=[Math]::Min(88,$cardWidth-18)
    $pic=New-Object Windows.Forms.PictureBox; $pic.Width=$picSize; $pic.Height=$picSize; $pic.Left=[int](($cardWidth-$picSize)/2); $pic.Top=5; $pic.SizeMode="Zoom"; $pic.BackColor=[Drawing.Color]::White; $pic.Cursor=[Windows.Forms.Cursors]::Hand; $pic.Tag=$p
    if($p.image){$loaded=Load-ImageSafe $p.image;if($loaded){$pic.Image=$loaded}}
    $name=New-Object Windows.Forms.Label; $name.Text=$p.name; $name.Width=$cardWidth-12; $name.Left=6; $name.Top=95; $name.Height=42; $name.TextAlign="MiddleCenter"; $name.Font=New-Object Drawing.Font("Segoe UI",8,[Drawing.FontStyle]::Bold); $name.Cursor=[Windows.Forms.Cursors]::Hand; $name.Tag=$p
    $code=New-Object Windows.Forms.Label; $code.Text=$p.code; $code.Width=$cardWidth-12; $code.Left=6; $code.Top=139; $code.Height=25; $code.TextAlign="MiddleCenter"; $code.Font=New-Object Drawing.Font("Segoe UI",7.8,[Drawing.FontStyle]::Bold); $code.ForeColor=[Drawing.Color]::FromArgb(225,12,20); $code.Cursor=[Windows.Forms.Cursors]::Hand; $code.Tag=$p
    $card.Controls.AddRange(@($pic,$name,$code))
    $card.Add_PreviewKeyDown({ if($_.KeyCode -in @([Windows.Forms.Keys]::Left,[Windows.Forms.Keys]::Right,[Windows.Forms.Keys]::Up,[Windows.Forms.Keys]::Down,[Windows.Forms.Keys]::Enter)){ $_.IsInputKey=$true } })
    $pic.Add_PreviewKeyDown({ if($_.KeyCode -in @([Windows.Forms.Keys]::Left,[Windows.Forms.Keys]::Right,[Windows.Forms.Keys]::Up,[Windows.Forms.Keys]::Down,[Windows.Forms.Keys]::Enter)){ $_.IsInputKey=$true } })
    $name.Add_PreviewKeyDown({ if($_.KeyCode -in @([Windows.Forms.Keys]::Left,[Windows.Forms.Keys]::Right,[Windows.Forms.Keys]::Up,[Windows.Forms.Keys]::Down,[Windows.Forms.Keys]::Enter)){ $_.IsInputKey=$true } })
    $code.Add_PreviewKeyDown({ if($_.KeyCode -in @([Windows.Forms.Keys]::Left,[Windows.Forms.Keys]::Right,[Windows.Forms.Keys]::Up,[Windows.Forms.Keys]::Down,[Windows.Forms.Keys]::Enter)){ $_.IsInputKey=$true } })
    $click={ param($sender,$e); if($sender.Tag){ Send-Code $sender.Tag.code; $script:selectedProductIndex=[Math]::Max(0,$script:productCards.IndexOf($sender)); Highlight-ProductCard } }
    $card.Add_Click($click); $name.Add_Click($click); $code.Add_Click($click); $pic.Add_Click($click)
    $card.Add_Enter({Highlight-ProductCard})
    $card.Add_KeyDown({if(Handle-NavigationKey $_.KeyCode){$_.Handled=$true;$_.SuppressKeyPress=$true}})
    $pic.Add_KeyDown({if(Handle-NavigationKey $_.KeyCode){$_.Handled=$true;$_.SuppressKeyPress=$true}})
    $name.Add_KeyDown({if(Handle-NavigationKey $_.KeyCode){$_.Handled=$true;$_.SuppressKeyPress=$true}})
    $code.Add_KeyDown({if(Handle-NavigationKey $_.KeyCode){$_.Handled=$true;$_.SuppressKeyPress=$true}})
    $productPanel.Controls.Add($card); $script:productCards += $card
  }
  if($items.Count -eq 0){$empty=New-Object Windows.Forms.Label; $empty.Text="No hay productos para mostrar."; $empty.AutoSize=$true; $empty.Font=New-Object Drawing.Font("Segoe UI",10); $empty.ForeColor=[Drawing.Color]::Gray; $empty.Margin=New-Object Windows.Forms.Padding(25,25,0,0); $productPanel.Controls.Add($empty)}
  $productPanel.ResumeLayout()
  Highlight-ProductCard
}
function Highlight-ProductCard {
  for($i=0;$i -lt $script:productCards.Count;$i++){
    $card=$script:productCards[$i]
    $selected=($i -eq $script:selectedProductIndex)
    if($selected){
      $card.BackColor=[Drawing.Color]::FromArgb(255,240,175)
      $card.BorderStyle="Fixed3D"
      foreach($child in $card.Controls){ try {$child.BackColor=[Drawing.Color]::FromArgb(255,240,175)} catch {} }
    } else {
      $card.BackColor=[Drawing.Color]::White
      $card.BorderStyle="FixedSingle"
      foreach($child in $card.Controls){ try {$child.BackColor=[Drawing.Color]::White} catch {} }
    }
  }
  if($script:selectedProductIndex -ge 0 -and $script:selectedProductIndex -lt $script:productCards.Count){
    try {
      $selectedCard=$script:productCards[$script:selectedProductIndex]
      $productPanel.ScrollControlIntoView($selectedCard)
      $selectedCard.Focus()
    } catch {}
  }
}
function Get-SelectedCategoryIndex {
  $cats=@(Get-VisibleCategories)
  if($cats.Count -eq 0 -or $null -eq $script:selectedCategory){return -1}
  for($i=0;$i -lt $cats.Count;$i++){ if($cats[$i] -eq $script:selectedCategory){return $i} }
  return -1
}
function Ensure-CategoryVisible([int]$idx) {
  if($idx -lt 0 -or $idx -ge $script:categoryButtons.Count){return}
  try {
    $categoryFlow.PerformLayout()
    $categoryFlow.Update()
    $b=$script:categoryButtons[$idx]
    $view=[int]$categoryViewport.ClientSize.Width
    $content=[int]$categoryFlow.PreferredSize.Width
    $max=[Math]::Max(0,$content-$view)
    $left=[int]$b.Left
    $right=$left+[int]$b.Width
    $value=[int]$categoryHScroll.Value
    if($left -lt $value){$value=$left}
    elseif($right -gt ($value+$view)){$value=$right-$view}
    $value=[Math]::Max(0,[Math]::Min($value,$max))
    $categoryHScroll.Maximum=[Math]::Max(0,$max+$categoryHScroll.LargeChange-1)
    $categoryHScroll.Value=[Math]::Min($value,[Math]::Max(0,$categoryHScroll.Maximum-$categoryHScroll.LargeChange+1))
    $categoryFlow.Left=-[int]$categoryHScroll.Value
    $categoryFlow.Update()
  } catch {}
}
function Move-CategorySelection([int]$delta) {
  $cats=@(Get-VisibleCategories); if($cats.Count -eq 0){return}
  $idx=Get-SelectedCategoryIndex
  if($idx -lt 0){$idx=0}else{$idx=($idx+$delta)%$cats.Count;if($idx -lt 0){$idx=$cats.Count-1}}
  $script:selectedCategory=$cats[$idx]
  $script:selectedProductIndex=0
  Refresh-CategoryButtons
  Ensure-CategoryVisible $idx
  Show-Products $script:selectedCategory
  Highlight-ProductCard
  foreach($b in $script:categoryButtons){
    $selected=($b.Tag -eq $script:selectedCategory)
    if($selected){
      $b.BackColor=[Drawing.Color]::FromArgb(255,206,0)
      $b.ForeColor=[Drawing.Color]::Black
      $b.FlatAppearance.BorderSize=2
      $b.FlatAppearance.BorderColor=[Drawing.Color]::FromArgb(225,12,20)
    } else {
      $b.BackColor=[Drawing.Color]::White
      $b.ForeColor=[Drawing.Color]::FromArgb(45,45,45)
      $b.FlatAppearance.BorderSize=1
      $b.FlatAppearance.BorderColor=[Drawing.Color]::LightGray
    }
  }
  Ensure-CategoryVisible $idx
  try {$script:categoryButtons[$idx].Focus()} catch {}
}
function Move-ProductSelection([int]$delta) {
  $count=$script:productCards.Count; if($count -eq 0){return}
  $new=$script:selectedProductIndex+$delta
  if($new -lt 0){$new=0}; if($new -ge $count){$new=$count-1}
  $script:selectedProductIndex=$new
  Highlight-ProductCard
}

function Update-CategoryScroll {
  $categoryViewport.Width=[Math]::Max(200,$main.ClientSize.Width-16)
  $categoryHScroll.Width=$categoryViewport.Width
  $categoryHScroll.LargeChange=[Math]::Max(1,$categoryViewport.ClientSize.Width)
  $categoryFlow.PerformLayout()
  $contentWidth=[Math]::Max(0,[int]$categoryFlow.PreferredSize.Width-[int]$categoryViewport.ClientSize.Width)
  $categoryHScroll.Minimum=0
  $categoryHScroll.Maximum=[Math]::Max(0,$contentWidth+$categoryHScroll.LargeChange-1)
  $maxValue=[Math]::Max(0,$categoryHScroll.Maximum-$categoryHScroll.LargeChange+1)
  if($categoryHScroll.Value -gt $maxValue){$categoryHScroll.Value=$maxValue}
  $categoryFlow.Left=-[int]$categoryHScroll.Value
}
function Refresh-CategoryButtons {
  $categoryFlow.SuspendLayout()
  $categoryFlow.Controls.Clear()
  $script:categoryButtons=@()
  foreach($c in (Get-VisibleCategories)){
    $b=New-Object Windows.Forms.Button
    $b.Text=$c.name
    $b.Tag=$c
    $b.AutoSize=$false
    $b.Height=34
    # Ancho calculado con la fuente para que nunca se corte el nombre.
    $fontTemp=New-Object Drawing.Font("Segoe UI",8.5,[Drawing.FontStyle]::Bold)
    $textSize=[Windows.Forms.TextRenderer]::MeasureText($b.Text,$fontTemp)
    $fontTemp.Dispose()
    $b.Width=[Math]::Max(88,$textSize.Width+24)
    $b.MinimumSize=New-Object Drawing.Size(88,34)
    $b.Padding=New-Object Windows.Forms.Padding(10,0,10,0)
    $b.Margin=New-Object Windows.Forms.Padding(3,3,3,3)
    $b.AutoEllipsis=$false
    $b.FlatStyle="Flat"
    $b.FlatAppearance.BorderSize=1
    $b.Font=New-Object Drawing.Font("Segoe UI",8.5,[Drawing.FontStyle]::Bold)
    $b.BackColor=[Drawing.Color]::White
    $b.ForeColor=[Drawing.Color]::FromArgb(45,45,45)
    $b.FlatAppearance.BorderColor=[Drawing.Color]::FromArgb(225,12,20)
    $b.Cursor=[Windows.Forms.Cursors]::Hand
    $clickCat={param($sender,$e); if($sender.Tag){$script:selectedCategory=$sender.Tag; $script:selectedProductIndex=0; Refresh-CategoryButtons; $idx=Get-SelectedCategoryIndex; Ensure-CategoryVisible $idx; Show-Products $script:selectedCategory; Highlight-ProductCard; Ensure-CategoryVisible $idx; try{$script:categoryButtons[$idx].Focus()}catch{}}}
    $b.Add_Click($clickCat)
    $b.Add_KeyDown({if(Handle-NavigationKey $_.KeyCode){$_.Handled=$true;$_.SuppressKeyPress=$true}})
    $b.TabStop=$true
    $b.Add_PreviewKeyDown({ if($_.KeyCode -in @([Windows.Forms.Keys]::Left,[Windows.Forms.Keys]::Right,[Windows.Forms.Keys]::Up,[Windows.Forms.Keys]::Down,[Windows.Forms.Keys]::Enter)){ $_.IsInputKey=$true } })
    $categoryFlow.Controls.Add($b)
    $script:categoryButtons += $b
  }
  foreach($b in $script:categoryButtons){
    if($b.Tag -eq $script:selectedCategory){
      $b.BackColor=[Drawing.Color]::FromArgb(255,220,70)
      $b.FlatAppearance.BorderSize=2
    }
  }
  $categoryFlow.ResumeLayout()
  Update-CategoryScroll
  $selIdx=Get-SelectedCategoryIndex
  if($selIdx -ge 0){Ensure-CategoryVisible $selIdx}
  foreach($btn in $script:categoryButtons){
    if($btn.Tag -eq $script:selectedCategory){
      $btn.BackColor=[Drawing.Color]::FromArgb(255,206,0); $btn.ForeColor=[Drawing.Color]::Black; $btn.FlatAppearance.BorderSize=2; $btn.FlatAppearance.BorderColor=[Drawing.Color]::FromArgb(225,12,20)
    } else {
      $btn.BackColor=[Drawing.Color]::White; $btn.ForeColor=[Drawing.Color]::FromArgb(45,45,45); $btn.FlatAppearance.BorderSize=1; $btn.FlatAppearance.BorderColor=[Drawing.Color]::LightGray
    }
  }
}
$categoryHScroll.Add_Scroll({ $categoryFlow.Left=-$categoryHScroll.Value })

function Refresh-View {
  if($null -eq $script:selectedCategory -or (Get-VisibleCategories) -notcontains $script:selectedCategory){$vc=@(Get-VisibleCategories);if($vc.Count -gt 0){$script:selectedCategory=$vc[0]}}
  Refresh-CategoryButtons
  if($script:selectedCategory){Show-Products $script:selectedCategory}
}
$productSearch.Add_TextChanged({if($script:selectedCategory){Show-Products $script:selectedCategory}})
$gear.Add_Click({if($IsAdmin){Configure}else{Configure-Client}})


function Show-CashCounter {
  $cf=New-Object Windows.Forms.Form
  $cf.Text="₡ Conteo de efectivo"
  $cf.StartPosition="CenterScreen"
  $cf.Size=New-Object Drawing.Size(760,700)
  $cf.MinimumSize=New-Object Drawing.Size(720,620)
  $cf.BackColor=[Drawing.Color]::White

  $title=New-Object Windows.Forms.Label
  $title.Text="₡  CONTEO DE EFECTIVO"
  $title.Font=New-Object Drawing.Font("Segoe UI",18,[Drawing.FontStyle]::Bold)
  $title.AutoSize=$true
  $title.Location=New-Object Drawing.Point(25,18)
  $cf.Controls.Add($title)

  $lc=New-Object Windows.Forms.Label
  $lc.Text="Cajero/a:"
  $lc.Location=New-Object Drawing.Point(28,65)
  $lc.AutoSize=$true
  $cf.Controls.Add($lc)

  $tc=New-Object Windows.Forms.TextBox
  $tc.Location=New-Object Drawing.Point(95,61)
  $tc.Width=250
  $cf.Controls.Add($tc)

  $g=New-Object Windows.Forms.DataGridView
  $g.Location=New-Object Drawing.Point(25,100)
  $g.Size=New-Object Drawing.Size(690,390)
  $g.AllowUserToAddRows=$false
  $g.AllowUserToDeleteRows=$false
  $g.AllowUserToResizeRows=$false
  $g.RowHeadersVisible=$false
  $g.AutoSizeColumnsMode="Fill"
  $g.SelectionMode="CellSelect"
  $g.EditMode="EditOnEnter"
  $g.MultiSelect=$false
  $g.ColumnCount=4
  $g.Columns[0].Name="Denominación"
  $g.Columns[1].Name="Cantidad"
  $g.Columns[2].Name="Suma"
  $g.Columns[3].Name="Tipo"

  # Solo la columna Cantidad queda habilitada para escribir.
  $g.Columns[0].ReadOnly=$true
  $g.Columns[1].ReadOnly=$false
  $g.Columns[2].ReadOnly=$true
  $g.Columns[3].ReadOnly=$true
  $g.Columns[0].DefaultCellStyle.BackColor=[Drawing.Color]::Gainsboro
  $g.Columns[2].DefaultCellStyle.BackColor=[Drawing.Color]::Gainsboro
  $g.Columns[3].DefaultCellStyle.BackColor=[Drawing.Color]::Gainsboro
  $g.Columns[1].DefaultCellStyle.BackColor=[Drawing.Color]::White

  $d=@(
    @{v=20000;t="Billete"},
    @{v=10000;t="Billete"},
    @{v=5000;t="Billete"},
    @{v=2000;t="Billete"},
    @{v=1000;t="Billete"},
    @{v=500;t="Moneda"},
    @{v=100;t="Moneda"},
    @{v=50;t="Moneda"},
    @{v=25;t="Moneda"},
    @{v=10;t="Moneda"},
    @{v=1;t="₡1 adicional"}
  )
  foreach($x in $d){[void]$g.Rows.Add(("₡{0:N0}" -f $x.v),0,"₡0",$x.t)}
  $cf.Controls.Add($g)

  $tot=New-Object Windows.Forms.Label
  $tot.Text="TOTAL: ₡0"
  $tot.Font=New-Object Drawing.Font("Segoe UI",16,[Drawing.FontStyle]::Bold)
  $tot.AutoSize=$true
  $tot.Location=New-Object Drawing.Point(25,510)
  $cf.Controls.Add($tot)

  $save=New-Object Windows.Forms.Button
  $save.Text="Guardar conteo"
  $save.Location=New-Object Drawing.Point(530,505)
  $save.Size=New-Object Drawing.Size(150,36)
  $cf.Controls.Add($save)

  $view=New-Object Windows.Forms.Button
  $view.Text="Ver conteos guardados"
  $view.Location=New-Object Drawing.Point(530,550)
  $view.Size=New-Object Drawing.Size(150,36)
  $cf.Controls.Add($view)

  $clear=New-Object Windows.Forms.Button
  $clear.Text="Limpiar"
  $clear.Location=New-Object Drawing.Point(25,595)
  $clear.Size=New-Object Drawing.Size(100,32)
  $cf.Controls.Add($clear)

  $calc={
    $sum=0
    for($i=0;$i -lt $g.Rows.Count;$i++){
      $q=0
      [void][int]::TryParse([string]$g.Rows[$i].Cells[1].Value,[ref]$q)
      if($q -lt 0){$q=0}
      $v=[int]$d[$i].v
      $z=$v*$q
      $g.Rows[$i].Cells[2].Value=("₡{0:N0}" -f $z)
      $sum+=$z
    }
    $tot.Text=("TOTAL: ₡{0:N0}" -f $sum)
    return $sum
  }

  # Validación: en la columna Cantidad solo se aceptan números enteros.
  $g.add_CellValidating({
    param($sender,$e)
    if($e.ColumnIndex -eq 1){
      $txt=[string]$e.FormattedValue
      if([string]::IsNullOrWhiteSpace($txt)){
        $e.Cancel=$false
      } else {
        $n=0
        if(-not [int]::TryParse($txt,[ref]$n) -or $n -lt 0){
          $e.Cancel=$true
          [Windows.Forms.MessageBox]::Show("Solo puedes escribir una cantidad numérica.","Conteo de efectivo")|Out-Null
        }
      }
    } else {
      $e.Cancel=$false
    }
  })
  $g.add_CellValueChanged({&$calc})
  $g.add_CurrentCellDirtyStateChanged({
    if($g.IsCurrentCellDirty){
      $g.CommitEdit([Windows.Forms.DataGridViewDataErrorContexts]::Commit)
    }
  })

  $clear.Add_Click({
    foreach($r in $g.Rows){$r.Cells[1].Value=0}
    &$calc
  })

  $save.Add_Click({
    $total=&$calc
    $name=$tc.Text.Trim()
    if([string]::IsNullOrWhiteSpace($name)){
      [Windows.Forms.MessageBox]::Show("Indica el nombre del cajero/a.","Conteo")|Out-Null
      return
    }
    $dir=Join-Path $AppDir "Conteos_Efectivo"
    if(!(Test-Path $dir)){New-Item -ItemType Directory -Path $dir -Force|Out-Null}
    $stamp=Get-Date -Format "yyyyMMdd_HHmmss"
    $safe=$name-replace '[\\/:*?"<>|]','_'
    $file=Join-Path $dir ("Conteo_{0}_{1}.csv"-f $stamp,$safe)
    $rows=@()
    for($i=0;$i-lt $g.Rows.Count;$i++){
      $q=0
      [void][int]::TryParse([string]$g.Rows[$i].Cells[1].Value,[ref]$q)
      $rows += [pscustomobject]@{
        Fecha=(Get-Date -Format "yyyy-MM-dd HH:mm:ss")
        Cajero=$name
        Denominacion=$d[$i].v
        Cantidad=$q
        Suma=($d[$i].v*$q)
        Tipo=$d[$i].t
        Total=$total
      }
    }
    $rows|Export-Csv -LiteralPath $file -NoTypeInformation -Encoding UTF8
    [Windows.Forms.MessageBox]::Show("Conteo guardado correctamente.","Conteo")|Out-Null
  })

  $view.Add_Click({
    $dir=Join-Path $AppDir "Conteos_Efectivo"
    if(!(Test-Path $dir)){New-Item -ItemType Directory -Path $dir -Force|Out-Null}

    $files=@(Get-ChildItem -LiteralPath $dir -Filter "*.csv" -File|Sort-Object LastWriteTime -Descending)

    $vf=New-Object Windows.Forms.Form
    $vf.Text="Conteos guardados"
    $vf.StartPosition="CenterParent"
    $vf.Size=New-Object Drawing.Size(980,620)
    $vf.MinimumSize=New-Object Drawing.Size(850,520)
    $vf.BackColor=[Drawing.Color]::White

    $vt=New-Object Windows.Forms.Label
    $vt.Text="CONTEOS GUARDADOS"
    $vt.Font=New-Object Drawing.Font("Segoe UI",16,[Drawing.FontStyle]::Bold)
    $vt.AutoSize=$true
    $vt.Location=New-Object Drawing.Point(20,15)
    $vf.Controls.Add($vt)

    $list=New-Object Windows.Forms.ListBox
    $list.Location=New-Object Drawing.Point(20,55)
    $list.Size=New-Object Drawing.Size(300,480)
    $vf.Controls.Add($list)

    foreach($f in $files){
      try{
        $r=@(Import-Csv -LiteralPath $f.FullName)
        if($r.Count){
          [void]$list.Items.Add(("{0} | {1} | ₡{2:N0}" -f $r[0].Fecha,$r[0].Cajero,[int]$r[0].Total))
        }
      }catch{}
    }

    $hint=New-Object Windows.Forms.Label
    $hint.Text="Doble clic en un conteo para abrirlo en una pestaña."
    $hint.AutoSize=$true
    $hint.Location=New-Object Drawing.Point(340,55)
    $vf.Controls.Add($hint)

    $tabs=New-Object Windows.Forms.TabControl
    $tabs.Location=New-Object Drawing.Point(340,85)
    $tabs.Size=New-Object Drawing.Size(600,440)
    $tabs.Anchor=[Windows.Forms.AnchorStyles]::Top -bor [Windows.Forms.AnchorStyles]::Bottom -bor [Windows.Forms.AnchorStyles]::Left -bor [Windows.Forms.AnchorStyles]::Right
    $vf.Controls.Add($tabs)

    $openDetail={
      $idx=$list.SelectedIndex
      if($idx -lt 0 -or $idx -ge $files.Count){return}
      try{
        $r=@(Import-Csv -LiteralPath $files[$idx].FullName)
        if(!$r.Count){return}

        $tabName="Conteo - {0}" -f $r[0].Cajero
        $tp=New-Object Windows.Forms.TabPage
        $tp.Text=$tabName

        $info=New-Object Windows.Forms.Label
        $info.Text=("Cajero/a: {0}    Fecha: {1}" -f $r[0].Cajero,$r[0].Fecha)
        $info.AutoSize=$true
        $info.Location=New-Object Drawing.Point(15,15)
        $tp.Controls.Add($info)

        $dg=New-Object Windows.Forms.DataGridView
        $dg.Location=New-Object Drawing.Point(15,50)
        $dg.Size=New-Object Drawing.Size(555,300)
        $dg.ReadOnly=$true
        $dg.AllowUserToAddRows=$false
        $dg.AllowUserToDeleteRows=$false
        $dg.RowHeadersVisible=$false
        $dg.AutoSizeColumnsMode="Fill"
        $dg.ColumnCount=4
        $dg.Columns[0].Name="Denominación"
        $dg.Columns[1].Name="Cantidad"
        $dg.Columns[2].Name="Suma"
        $dg.Columns[3].Name="Tipo"
        $tp.Controls.Add($dg)

        foreach($row in $r){
          [void]$dg.Rows.Add(
            ("₡{0:N0}" -f [int]$row.Denominacion),
            [int]$row.Cantidad,
            ("₡{0:N0}" -f [int]$row.Suma),
            $row.Tipo
          )
        }

        $detailTotal=New-Object Windows.Forms.Label
        $detailTotal.Text=("TOTAL GENERAL: ₡{0:N0}" -f [int]$r[0].Total)
        $detailTotal.Font=New-Object Drawing.Font("Segoe UI",15,[Drawing.FontStyle]::Bold)
        $detailTotal.AutoSize=$true
        $detailTotal.Location=New-Object Drawing.Point(15,365)
        $tp.Controls.Add($detailTotal)

        [void]$tabs.TabPages.Add($tp)
        $tabs.SelectedTab=$tp
      }catch{
        [Windows.Forms.MessageBox]::Show("No se pudo abrir el conteo.`n$($_.Exception.Message)","Conteos guardados")|Out-Null
      }
    }

    $list.Add_DoubleClick({&$openDetail})

    $btnOpenFolder=New-Object Windows.Forms.Button
    $btnOpenFolder.Text="Abrir carpeta"
    $btnOpenFolder.Location=New-Object Drawing.Point(20,545)
    $btnOpenFolder.Size=New-Object Drawing.Size(140,34)
    $vf.Controls.Add($btnOpenFolder)
    $btnOpenFolder.Add_Click({
      try{Start-Process explorer.exe -ArgumentList "`"$dir`""}catch{}
    })

    if($list.Items.Count -gt 0){$list.SelectedIndex=0}
    $vf.ShowDialog($cf)|Out-Null
    $vf.Dispose()
  })

  &$calc
  $cf.ShowDialog()|Out-Null
  $cf.Dispose()
}
function Manage-ClientProducts {
  $f=New-Object Windows.Forms.Form
  $f.Text="Musi LDCOM - Productos locales"
  $f.StartPosition="CenterParent"
  $f.Size=New-Object Drawing.Size(900,650)
  $f.MinimumSize=New-Object Drawing.Size(820,580)
  $f.BackColor=[Drawing.Color]::White

  $cat=New-Object Windows.Forms.ComboBox; $cat.Location=New-Object Drawing.Point(20,20); $cat.Width=330; $cat.DropDownStyle='DropDownList'; $cat.DisplayMember='name'; $f.Controls.Add($cat)
  $list=New-Object Windows.Forms.ListBox; $list.Location=New-Object Drawing.Point(20,60); $list.Size=New-Object Drawing.Size(330,470); $f.Controls.Add($list)
  $nm=New-Object Windows.Forms.TextBox; $nm.Location=New-Object Drawing.Point(385,55); $nm.Width=450; $f.Controls.Add($nm)
  $cd=New-Object Windows.Forms.TextBox; $cd.Location=New-Object Drawing.Point(385,120); $cd.Width=450; $f.Controls.Add($cd)
  $im=New-Object Windows.Forms.TextBox; $im.Location=New-Object Drawing.Point(385,185); $im.Width=300; $im.ReadOnly=$true; $f.Controls.Add($im)
  $ib=New-Object Windows.Forms.Button; $ib.Text='Cambiar imagen'; $ib.Location=New-Object Drawing.Point(695,183); $ib.Width=140; $f.Controls.Add($ib)
  $preview=New-Object Windows.Forms.PictureBox; $preview.Location=New-Object Drawing.Point(385,225); $preview.Size=New-Object Drawing.Size(150,150); $preview.BorderStyle='FixedSingle'; $preview.SizeMode='Zoom'; $f.Controls.Add($preview)
  foreach($x in @(@('Nombre',385,30),@('Código LDCOM',385,95),@('Imagen',385,160))){$l=New-Object Windows.Forms.Label;$l.Text=$x[0];$l.Location=New-Object Drawing.Point($x[1],$x[2]);$l.AutoSize=$true;$f.Controls.Add($l)}
  $save=New-Object Windows.Forms.Button; $save.Text='Guardar cambios'; $save.Location=New-Object Drawing.Point(385,410); $save.Width=160; $save.Height=40; $f.Controls.Add($save)
  $new=New-Object Windows.Forms.Button; $new.Text='Nuevo producto'; $new.Location=New-Object Drawing.Point(555,410); $new.Width=150; $new.Height=40; $f.Controls.Add($new)
  $info=New-Object Windows.Forms.Label; $info.Text='Los cambios se guardan únicamente en esta copia cliente y permanecen después de actualizar el programa.'; $info.Location=New-Object Drawing.Point(385,470); $info.Width=450; $info.Height=55; $f.Controls.Add($info)

  function Refresh-LocalProducts {
    $list.Items.Clear(); $c=$cat.SelectedItem; if($null -eq $c){return}
    foreach($p in (A $c.products)){[void]$list.Items.Add([string]$p.name)}
  }
  foreach($c in (A $data.categories)){[void]$cat.Items.Add($c)}
  if($cat.Items.Count -gt 0){$cat.SelectedIndex=0}
  $cat.Add_SelectedIndexChanged({Refresh-LocalProducts})
  $list.Add_SelectedIndexChanged({
    $i=$list.SelectedIndex;$c=$cat.SelectedItem;if($i -lt 0 -or $null -eq $c){return};$p=(A $c.products)[$i]
    $nm.Text=[string]$p.name;$cd.Text=[string]$p.code;$im.Text=[string]$p.image
    if($preview.Image){$preview.Image.Dispose();$preview.Image=$null};if($p.image){$preview.Image=Load-ImageSafe $p.image}
  })
  $ib.Add_Click({
    $d=New-Object Windows.Forms.OpenFileDialog;$d.Filter='Imágenes|*.png;*.jpg;*.jpeg;*.bmp;*.gif'
    if($d.ShowDialog() -eq 'OK'){
      try{$ext=[IO.Path]::GetExtension($d.FileName).ToLowerInvariant();$safe=((($nm.Text.Trim()) -replace '[^a-zA-Z0-9_-]','_').Trim('_'));if(!$safe){$safe='producto'};$destName="$safe$ext";$dest=Join-Path $ImageDir $destName;$n=1;while(Test-Path $dest){$destName="${safe}_$n$ext";$dest=Join-Path $ImageDir $destName;$n++};Copy-Item -LiteralPath $d.FileName -Destination $dest -Force;$im.Text="images\$destName";if($preview.Image){$preview.Image.Dispose();$preview.Image=$null};$preview.Image=Load-ImageSafe $im.Text}catch{[Windows.Forms.MessageBox]::Show($_.Exception.Message)|Out-Null}
    }
  })
  $save.Add_Click({
    $i=$list.SelectedIndex;$c=$cat.SelectedItem;if($i -lt 0 -or $null -eq $c){[Windows.Forms.MessageBox]::Show('Selecciona un producto.')|Out-Null;return};$p=(A $c.products)[$i]
    $p.name=$nm.Text.Trim();$p.code=$cd.Text.Trim();$p.image=$im.Text.Trim();Save-ClientCatalog $data;Refresh-LocalProducts;$list.SelectedIndex=$i;Refresh-View
  })
  $new.Add_Click({
    $c=$cat.SelectedItem;if($null -eq $c){return};$p=[PSCustomObject]@{name='Nuevo producto';code='';image=''};$c.products=@((A $c.products)+$p);Save-ClientCatalog $data;Refresh-LocalProducts;$list.SelectedIndex=$list.Items.Count-1;Refresh-View
  })
  Refresh-LocalProducts
  [void]$f.ShowDialog($panel)
}

function Configure-Client {
  $f=New-Object Windows.Forms.Form
$f.Text="Musi LDCOM - Configuración"
  $f.StartPosition="CenterScreen"
  $f.Size=New-Object Drawing.Size(560,730)
  $f.MinimumSize=New-Object Drawing.Size(560,730)
  $f.BackColor=[Drawing.Color]::White

  $title=New-Object Windows.Forms.Label; $title.Text="Categorías visibles en esta computadora"; $title.Font=New-Object Drawing.Font("Segoe UI",13,[Drawing.FontStyle]::Bold); $title.Location=New-Object Drawing.Point(25,20); $title.AutoSize=$true; $f.Controls.Add($title)
  $list=New-Object Windows.Forms.CheckedListBox; $list.Location=New-Object Drawing.Point(25,60); $list.Size=New-Object Drawing.Size(500,300); $list.CheckOnClick=$true; $f.Controls.Add($list)
  $prefs=Load-ClientPrefs; $hidden=@($prefs.hiddenCategories | ForEach-Object {[string]$_})
  foreach($c in (A $data.categories)) {[void]$list.Items.Add([string]$c.name, -not ((Get-CategoryHidden $c) -or ($hidden -contains [string]$c.name)))}
  $all=New-Object Windows.Forms.Button; $all.Text="Mostrar todas"; $all.Location=New-Object Drawing.Point(25,370); $all.Width=145; $f.Controls.Add($all)
  $none=New-Object Windows.Forms.Button; $none.Text="Ocultar todas"; $none.Location=New-Object Drawing.Point(180,370); $none.Width=145; $f.Controls.Add($none)
  $save=New-Object Windows.Forms.Button; $save.Text="Guardar categorías"; $save.Location=New-Object Drawing.Point(350,370); $save.Width=175; $f.Controls.Add($save)
  $all.Add_Click({for($i=0;$i -lt $list.Items.Count;$i++){$list.SetItemChecked($i,$true)}})
  $none.Add_Click({for($i=0;$i -lt $list.Items.Count;$i++){$list.SetItemChecked($i,$false)}})
  $save.Add_Click({$h=@();for($i=0;$i -lt $list.Items.Count;$i++){if(-not $list.GetItemChecked($i)){$h += [string]$list.Items[$i]}};Save-ClientPrefs ([PSCustomObject]@{hiddenCategories=$h});$f.Close();$script:selectedCategory=$null;Refresh-View})
  $prod=New-Object Windows.Forms.Button; $prod.Text="Editar / agregar productos"; $prod.Location=New-Object Drawing.Point(25,410); $prod.Width=220; $prod.Height=38; $f.Controls.Add($prod)
  $prod.Add_Click({Manage-ClientProducts})

  $sg=New-Object Windows.Forms.GroupBox; $sg.Text="Conexión con LDCOM"; $sg.Location=New-Object Drawing.Point(25,460); $sg.Size=New-Object Drawing.Size(500,125); $f.Controls.Add($sg)
  $si=New-Object Windows.Forms.Label; $si.Text="Captura la posición del campo donde LDCOM recibe el código."; $si.Location=New-Object Drawing.Point(15,20); $si.AutoSize=$true; $sg.Controls.Add($si)
  $cap=New-Object Windows.Forms.Button; $cap.Text="Capturar buscador"; $cap.Width=180; $cap.Height=38; $cap.Location=New-Object Drawing.Point(15,48); $sg.Controls.Add($cap)
  $status=New-Object Windows.Forms.Label; $status.AutoSize=$true; $status.Location=New-Object Drawing.Point(210,60); $status.Text=if([bool](Get-Setting "hasTarget" $false)){"Posición guardada: $(Get-Setting "targetX" 0), $(Get-Setting "targetY" 0)"}else{"Sin posición configurada"}; $sg.Controls.Add($status)
  $cap.Add_Click({
    $f.Hide();$panel.Hide()
    [Windows.Forms.MessageBox]::Show("Después de pulsar Aceptar tienes 3 segundos para colocar el mouse sobre el buscador de LDCOM.","Capturar buscador")|Out-Null
    Start-Sleep -Seconds 3
    $pos=[Windows.Forms.Cursor]::Position
    Set-Setting "targetX" ([int]$pos.X); Set-Setting "targetY" ([int]$pos.Y); Set-Setting "hasTarget" $true
    $status.Text="Posición guardada: $($pos.X), $($pos.Y)"
    $panel.Show();$f.Show();$f.Activate()
  })

  $chk=New-Object Windows.Forms.CheckBox; $chk.Text="Hacer clic en el buscador automáticamente"; $chk.Checked=[bool]$(Get-Setting "clickSearch" $true); $chk.AutoSize=$true; $chk.Location=New-Object Drawing.Point(25,555); $f.Controls.Add($chk)
  $ent=New-Object Windows.Forms.CheckBox; $ent.Text="Presionar Enter después de enviar el código"; $ent.Checked=[bool]$(Get-Setting "sendEnter" $true); $ent.AutoSize=$true; $ent.Location=New-Object Drawing.Point(25,620); $f.Controls.Add($ent)
  $save1=New-Object Windows.Forms.Button; $save1.Text="Guardar configuración"; $save1.Width=190; $save1.Height=40; $save1.Location=New-Object Drawing.Point(25,655); $f.Controls.Add($save1)
  $save1.Add_Click({Set-Setting "clickSearch" $chk.Checked;Set-Setting "sendEnter" $ent.Checked;[Windows.Forms.MessageBox]::Show("Configuración guardada.")|Out-Null})

  $ug=New-Object Windows.Forms.GroupBox; $ug.Text="Actualizaciones"; $ug.Location=New-Object Drawing.Point(270,585); $ug.Size=New-Object Drawing.Size(255,105); $f.Controls.Add($ug)
  $us=New-Object Windows.Forms.TextBox; $us.Location=New-Object Drawing.Point(10,25); $us.Width=235; $us.Text=[string]$localSettings.updateSource; $ug.Controls.Add($us)
  $ub=New-Object Windows.Forms.Button; $ub.Text="Buscar actualización"; $ub.Location=New-Object Drawing.Point(10,58); $ub.Width=125; $ug.Controls.Add($ub)
  $usv=New-Object Windows.Forms.Button; $usv.Text="Guardar origen"; $usv.Location=New-Object Drawing.Point(140,58); $usv.Width=100; $ug.Controls.Add($usv)
  $usv.Add_Click({$localSettings.updateSource=$us.Text.Trim();Save-LocalSettings $localSettings;[Windows.Forms.MessageBox]::Show('Origen guardado.')|Out-Null})
  $ub.Add_Click({$localSettings.updateSource=$us.Text.Trim();Save-LocalSettings $localSettings;Check-ForUpdates $true})
  [void]$f.ShowDialog($panel)
}

# ---------------- Administration ----------------
function Configure {
  $f=New-Object Windows.Forms.Form; $f.Text="Musi LDCOM - ADMINISTRACIÓN"; $f.StartPosition="CenterScreen"; $f.Size=New-Object Drawing.Size(1050,720); $f.MinimumSize=New-Object Drawing.Size(900,620); $f.BackColor=[Drawing.Color]::White
  $tabs=New-Object Windows.Forms.TabControl; $tabs.Dock="Fill"; $f.Controls.Add($tabs)

  $tp1=New-Object Windows.Forms.TabPage; $tp1.Text="Conexión con LDCOM"; $tabs.TabPages.Add($tp1)
  $info=New-Object Windows.Forms.Label; $info.AutoSize=$false; $info.Width=900; $info.Height=70; $info.Location=New-Object Drawing.Point(25,25); $info.Text="Abre LDCOM, pulsa Capturar buscador y coloca el mouse sobre el campo donde LDCOM recibe el código."; $tp1.Controls.Add($info)
  $cap=New-Object Windows.Forms.Button; $cap.Text="Capturar buscador"; $cap.Width=190; $cap.Height=45; $cap.Location=New-Object Drawing.Point(25,110); $tp1.Controls.Add($cap)
  $status2=New-Object Windows.Forms.Label; $status2.AutoSize=$true; $status2.Location=New-Object Drawing.Point(235,124); $status2.Text=if($data.settings.hasTarget){"Posición guardada: $($data.settings.targetX), $($data.settings.targetY)"}else{"Sin posición configurada"}; $tp1.Controls.Add($status2)
  $chk=New-Object Windows.Forms.CheckBox; $chk.Text="Hacer clic en el buscador automáticamente"; $chk.Checked=[bool]$(Get-Setting "clickSearch" $true); $chk.AutoSize=$true; $chk.Location=New-Object Drawing.Point(25,180); $tp1.Controls.Add($chk)
  $ent=New-Object Windows.Forms.CheckBox; $ent.Text="Presionar Enter después de enviar el código"; $ent.Checked=[bool]$(Get-Setting "sendEnter" $true); $ent.AutoSize=$true; $ent.Location=New-Object Drawing.Point(25,215); $tp1.Controls.Add($ent)
  $save1=New-Object Windows.Forms.Button; $save1.Text="Guardar configuración"; $save1.Width=190; $save1.Height=40; $save1.Location=New-Object Drawing.Point(25,265); $tp1.Controls.Add($save1)

  $tp2=New-Object Windows.Forms.TabPage; $tp2.Text="Productos"; $tabs.TabPages.Add($tp2)
  $plab=New-Object Windows.Forms.Label; $plab.Text="Categoría"; $plab.Location=New-Object Drawing.Point(15,15); $plab.AutoSize=$true; $tp2.Controls.Add($plab)
  $pfilter=New-Object Windows.Forms.ComboBox; $pfilter.Location=New-Object Drawing.Point(15,38); $pfilter.Width=340; $pfilter.DropDownStyle="DropDownList"; $pfilter.DisplayMember="name"; $tp2.Controls.Add($pfilter)
  $list=New-Object Windows.Forms.ListBox; $list.Location=New-Object Drawing.Point(15,78); $list.Size=New-Object Drawing.Size(340,485); $tp2.Controls.Add($list)
  $lab1=New-Object Windows.Forms.Label; $lab1.Text="Nombre"; $lab1.Location=New-Object Drawing.Point(385,25); $tp2.Controls.Add($lab1)
  $nm=New-Object Windows.Forms.TextBox; $nm.Location=New-Object Drawing.Point(385,48); $nm.Width=470; $tp2.Controls.Add($nm)
  $lab2=New-Object Windows.Forms.Label; $lab2.Text="Código LDCOM"; $lab2.Location=New-Object Drawing.Point(385,88); $tp2.Controls.Add($lab2)
  $cd=New-Object Windows.Forms.TextBox; $cd.Location=New-Object Drawing.Point(385,111); $cd.Width=470; $tp2.Controls.Add($cd)
  $lab3=New-Object Windows.Forms.Label; $lab3.Text="Imagen del producto"; $lab3.Location=New-Object Drawing.Point(385,151); $tp2.Controls.Add($lab3)
  $im=New-Object Windows.Forms.TextBox; $im.Location=New-Object Drawing.Point(385,174); $im.Width=315; $im.ReadOnly=$true; $tp2.Controls.Add($im)
  $ib=New-Object Windows.Forms.Button; $ib.Text="Seleccionar imagen"; $ib.Location=New-Object Drawing.Point(710,172); $ib.Width=145; $tp2.Controls.Add($ib)
  $preview=New-Object Windows.Forms.PictureBox; $preview.Location=New-Object Drawing.Point(385,215); $preview.Size=New-Object Drawing.Size(150,150); $preview.BorderStyle="FixedSingle"; $preview.SizeMode="Zoom"; $preview.BackColor=[Drawing.Color]::White; $tp2.Controls.Add($preview)
  $imgNote=New-Object Windows.Forms.Label; $imgNote.Text="Formatos: PNG, JPG, JPEG, BMP, GIF"; $imgNote.Location=New-Object Drawing.Point(550,235); $imgNote.AutoSize=$true; $tp2.Controls.Add($imgNote)
  $lab4=New-Object Windows.Forms.Label; $lab4.Text="Categoría del producto"; $lab4.Location=New-Object Drawing.Point(550,275); $tp2.Controls.Add($lab4)
  $cb=New-Object Windows.Forms.ComboBox; $cb.Location=New-Object Drawing.Point(550,298); $cb.Width=305; $cb.DropDownStyle="DropDownList"; $cb.DisplayMember="name"; $tp2.Controls.Add($cb)
  $sv=New-Object Windows.Forms.Button; $sv.Text="Guardar producto"; $sv.Location=New-Object Drawing.Point(385,390); $sv.Width=145; $sv.Height=38; $tp2.Controls.Add($sv)
  $np=New-Object Windows.Forms.Button; $np.Text="Nuevo producto"; $np.Location=New-Object Drawing.Point(540,390); $np.Width=130; $np.Height=38; $tp2.Controls.Add($np)
  $dl=New-Object Windows.Forms.Button; $dl.Text="Eliminar producto"; $dl.Location=New-Object Drawing.Point(680,390); $dl.Width=145; $dl.Height=38; $tp2.Controls.Add($dl)
  $phelp=New-Object Windows.Forms.Label; $phelp.Text="Selecciona una categoría para ver y editar solamente sus productos. Las imágenes se copian automáticamente a la carpeta images."; $phelp.Location=New-Object Drawing.Point(385,455); $phelp.Width=470; $phelp.Height=60; $tp2.Controls.Add($phelp)

  $tp3=New-Object Windows.Forms.TabPage; $tp3.Text="Categorías"; $tabs.TabPages.Add($tp3)
  $clist=New-Object Windows.Forms.ListBox; $clist.Location=New-Object Drawing.Point(20,20); $clist.Size=New-Object Drawing.Size(380,530); $tp3.Controls.Add($clist)
  $clab=New-Object Windows.Forms.Label; $clab.Text="Nombre de categoría"; $clab.Location=New-Object Drawing.Point(435,35); $clab.AutoSize=$true; $tp3.Controls.Add($clab)
  $cn=New-Object Windows.Forms.TextBox; $cn.Location=New-Object Drawing.Point(435,58); $cn.Width=400; $tp3.Controls.Add($cn)
  $cnew=New-Object Windows.Forms.Button; $cnew.Text="Nueva categoría"; $cnew.Location=New-Object Drawing.Point(435,110); $cnew.Width=160; $cnew.Height=40; $tp3.Controls.Add($cnew)
  $csave=New-Object Windows.Forms.Button; $csave.Text="Guardar cambios"; $csave.Location=New-Object Drawing.Point(605,110); $csave.Width=160; $csave.Height=40; $tp3.Controls.Add($csave)
  $cdel=New-Object Windows.Forms.Button; $cdel.Text="Eliminar categoría"; $cdel.Location=New-Object Drawing.Point(435,165); $cdel.Width=160; $cdel.Height=40; $tp3.Controls.Add($cdel)
  $cvis=New-Object Windows.Forms.CheckBox; $cvis.Text="Visible en las copias"; $cvis.Location=New-Object Drawing.Point(435,220); $cvis.AutoSize=$true; $cvis.Checked=$true; $tp3.Controls.Add($cvis)
  $cnote=New-Object Windows.Forms.Label; $cnote.AutoSize=$false; $cnote.Width=430; $cnote.Height=120; $cnote.Location=New-Object Drawing.Point(435,315); $cnote.Text="No existe un límite fijo de categorías ni productos. La información se guarda en ldcom_data.json y las imágenes en la carpeta images."; $tp3.Controls.Add($cnote)

  $tp4=New-Object Windows.Forms.TabPage; $tp4.Text="Tamaño"; $tabs.TabPages.Add($tp4)
  $fields=@(@("Ancho de imagen",50,'imageWidth',40,400),@("Alto de imagen",100,'imageHeight',40,400),@("Ancho de tarjeta",150,'cardWidth',150,500),@("Alto de tarjeta",200,'cardHeight',180,500))
  $nums=@{}
  foreach($x in $fields){$l=New-Object Windows.Forms.Label;$l.Text=$x[0];$l.Location=New-Object Drawing.Point(30,[int]$x[1]);$l.AutoSize=$true;$tp4.Controls.Add($l);$n=New-Object Windows.Forms.NumericUpDown;$n.Location=New-Object Drawing.Point(220,[int]$x[1]);$n.Width=110;$n.Minimum=[decimal]$x[3];$n.Maximum=[decimal]$x[4];$n.Value=[decimal]$data.settings.($x[2]);$tp4.Controls.Add($n);$nums[$x[2]]=$n}
  $save4=New-Object Windows.Forms.Button;$save4.Text="Guardar tamaño";$save4.Width=160;$save4.Height=40;$save4.Location=New-Object Drawing.Point(30,260);$tp4.Controls.Add($save4)

  function Refresh-Admin {
    $list.Items.Clear(); $cb.Items.Clear(); $clist.Items.Clear(); $pfilter.Items.Clear()
    $all=[PSCustomObject]@{name="Todas las categorías"; isAll=$true}
    [void]$pfilter.Items.Add($all)
    foreach($c in (A $data.categories)){ [void]$cb.Items.Add($c); [void]$clist.Items.Add($c.name); [void]$pfilter.Items.Add([PSCustomObject]@{name=[string]$c.name; category=$c; isAll=$false}) }
    if($pfilter.Items.Count -gt 0){$pfilter.SelectedIndex=0}
    if($cb.Items.Count -gt 0 -and $cb.SelectedIndex -lt 0){$cb.SelectedIndex=0}
    Refresh-ProductList
  }
  function Refresh-ProductList {
    $list.Items.Clear(); $selected=$pfilter.SelectedItem
    $cats=if($selected -and -not [bool]$selected.isAll){@($selected.category)}else{@(A $data.categories)}
    foreach($c in $cats){
      foreach($p in (A $c.products)){ [void]$list.Items.Add("$($p.name)") }
    }
  }
  function Select-ProductFilterCategory($cat) {
    if($null -eq $cat){return}
    for($i=0;$i -lt $pfilter.Items.Count;$i++){
      $item=$pfilter.Items[$i]
      if(-not [bool]$item.isAll -and $item.category -eq $cat){$pfilter.SelectedIndex=$i;return}
    }
  }
  Refresh-Admin

  $pfilter.Add_SelectedIndexChanged({Refresh-ProductList})
  $clist.Add_SelectedIndexChanged({
    $idx=$clist.SelectedIndex
    if($idx -ge 0 -and $idx -lt (A $data.categories).Count){$cc=(A $data.categories)[$idx];$cn.Text=[string]$cc.name;$cvis.Checked=(-not (Get-CategoryHidden $cc))}
  })
  $list.Add_SelectedIndexChanged({
    $idx=$list.SelectedIndex; if($idx -lt 0){return}; $selected=$pfilter.SelectedItem
    $cats=if($selected -and -not [bool]$selected.isAll){@($selected.category)}else{@(A $data.categories)}; $n=0
    foreach($c in $cats){foreach($p in (A $c.products)){if($n -eq $idx){$nm.Text=$p.name;$cd.Text=$p.code;$im.Text=$p.image;$cb.SelectedItem=$c;if($preview.Image){$preview.Image.Dispose();$preview.Image=$null};if($p.image){$preview.Image=Load-ImageSafe $p.image};return};$n++}}
  })
  $ib.Add_Click({
    $d=New-Object Windows.Forms.OpenFileDialog; $d.Title="Seleccionar imagen del producto"; $d.Filter="Imágenes compatibles|*.png;*.jpg;*.jpeg;*.bmp;*.gif"; $d.Multiselect=$false
    if($d.ShowDialog() -eq "OK"){
      try {
        $ext=[IO.Path]::GetExtension($d.FileName).ToLowerInvariant(); $safeName=((($nm.Text.Trim()) -replace '[^a-zA-Z0-9_-]','_').Trim('_')); if([string]::IsNullOrWhiteSpace($safeName)){$safeName="producto"}; $destName="$safeName$ext"; $dest=Join-Path $ImageDir $destName; $i=1; while(Test-Path $dest){$destName="$safeName`_$i$ext";$dest=Join-Path $ImageDir $destName;$i++}; Copy-Item -LiteralPath $d.FileName -Destination $dest -Force; $im.Text="images\$destName"; if($preview.Image){$preview.Image.Dispose();$preview.Image=$null};$preview.Image=Load-ImageSafe $im.Text; if($null -eq $preview.Image){throw "No se pudo leer la imagen seleccionada."}
      } catch { [Windows.Forms.MessageBox]::Show("No se pudo agregar la imagen.`n`n$($_.Exception.Message)","Imagen",[Windows.Forms.MessageBoxButtons]::OK,[Windows.Forms.MessageBoxIcon]::Error)|Out-Null }
    }
  })
  $sv.Add_Click({
    $idx=$list.SelectedIndex; if($idx -lt 0){[Windows.Forms.MessageBox]::Show("Selecciona un producto.");return}; $n=0; $oldCat=$null; $oldP=$null
    $selected=$pfilter.SelectedItem; $cats=if($selected -and -not [bool]$selected.isAll){@($selected.category)}else{@(A $data.categories)}
    foreach($c in $cats){foreach($p in (A $c.products)){if($n -eq $idx){$oldCat=$c;$oldP=$p;break};$n++};if($oldP){break}}
    if($null -eq $oldP){return}
    $newCat=$cb.SelectedItem; if($null -eq $newCat){$newCat=$oldCat}
    if($newCat -ne $oldCat){$oldArr=A $oldCat.products;$oldCat.products=@($oldArr|Where-Object{$_ -ne $oldP});$newArr=A $newCat.products;$newArr += $oldP;$newCat.products=$newArr}
    $oldP.name=$nm.Text.Trim();$oldP.code=$cd.Text.Trim();$oldP.image=$im.Text.Trim();Save-Data $data;Refresh-Admin;Refresh-View
    if($newCat){Select-ProductFilterCategory $newCat;$cb.SelectedItem=$newCat}
  })
  $np.Add_Click({
    # Agrega siempre un producto nuevo al final de la categoría seleccionada.
    # Se fuerza la colección a arreglo para que funcione igual con 0, 1 o muchos productos.
    $c=$cb.SelectedItem
    if($null -eq $c){[Windows.Forms.MessageBox]::Show("Selecciona una categoría.");return}
    $newProduct=[PSCustomObject]@{name="Nuevo producto";code="";image=""}
    $currentProducts=@(A $c.products)
    $c.products=@($currentProducts + $newProduct)
    Save-Data $data

    # Actualizar la lista y volver a la categoría correcta sin limitar la cantidad de productos.
    Refresh-Admin
    Select-ProductFilterCategory $c
    $cb.SelectedItem=$c

    # Seleccionar exactamente el producto recién creado.
    $newIndex=-1
    for($i=0;$i -lt $list.Items.Count;$i++){
      if([string]$list.Items[$i] -eq "Nuevo producto"){$newIndex=$i}
    }
    if($newIndex -ge 0){$list.SelectedIndex=$newIndex}
  })
  $dl.Add_Click({
    $idx=$list.SelectedIndex;if($idx -lt 0){return};$n=0; $selected=$pfilter.SelectedItem; $cats=if($selected -and -not [bool]$selected.isAll){@($selected.category)}else{@(A $data.categories)}
    foreach($c in $cats){$arr=A $c.products;for($i=0;$i -lt $arr.Count;$i++){if($n -eq $idx){$r=[Windows.Forms.MessageBox]::Show("¿Eliminar '$($arr[$i].name)'?","Confirmar",[Windows.Forms.MessageBoxButtons]::YesNo,[Windows.Forms.MessageBoxIcon]::Warning);if($r -ne [Windows.Forms.DialogResult]::Yes){return};$c.products=@($arr|Where-Object{$_ -ne $arr[$i]});Save-Data $data;Refresh-Admin;Refresh-View;return};$n++}}
  })
  $cnew.Add_Click({
    $name=$cn.Text.Trim()
    if([string]::IsNullOrWhiteSpace($name)){[Windows.Forms.MessageBox]::Show("Escribe el nombre de la nueva categoría.");return}
    $exists=(A $data.categories)|Where-Object{([string]$_.name).Trim().ToLower() -eq $name.ToLower()}
    if($exists){[Windows.Forms.MessageBox]::Show("Ya existe una categoría con ese nombre.");return}
    $arr=A $data.categories;$new=[PSCustomObject]@{name=$name;icon="";hidden=$false;products=@()};$arr += $new;$data.categories=$arr;Save-Data $data;Refresh-Admin;$script:selectedCategory=$new;Refresh-View;$clist.SelectedIndex=$clist.Items.Count-1
  })
  $csave.Add_Click({
    $idx=$clist.SelectedIndex;if($idx -lt 0){[Windows.Forms.MessageBox]::Show("Selecciona una categoría para editar.");return}
    $name=$cn.Text.Trim();if([string]::IsNullOrWhiteSpace($name)){[Windows.Forms.MessageBox]::Show("El nombre no puede quedar vacío.");return}
    $c=(A $data.categories)[$idx]
    $dup=(A $data.categories)|Where-Object{$_ -ne $c -and ([string]$_.name).Trim().ToLower() -eq $name.ToLower()}
    if($dup){[Windows.Forms.MessageBox]::Show("Ya existe otra categoría con ese nombre.");return}
    $c.name=$name;$c.hidden=(-not $cvis.Checked);Save-Data $data;Refresh-Admin;Refresh-View;$clist.SelectedIndex=$idx;$cn.Text=$c.name;$cvis.Checked=(-not (Get-CategoryHidden $c))
  })
  $cdel.Add_Click({
    $idx=$clist.SelectedIndex;if($idx -lt 0){return};if((A $data.categories).Count -le 1){[Windows.Forms.MessageBox]::Show("Debe existir al menos una categoría.");return}
    $c=(A $data.categories)[$idx];$r=[Windows.Forms.MessageBox]::Show("¿Eliminar '$($c.name)' y todos sus productos?","Confirmar",[Windows.Forms.MessageBoxButtons]::YesNo,[Windows.Forms.MessageBoxIcon]::Warning);if($r -ne [Windows.Forms.DialogResult]::Yes){return}
    $data.categories=@((A $data.categories)|Where-Object{$_ -ne $c});Save-Data $data;$script:selectedCategory=(A $data.categories)[0];Refresh-Admin;Refresh-View
  })
  $cap.Add_Click({$f.Hide();$panel.Hide();[Windows.Forms.MessageBox]::Show("Después de pulsar Aceptar tienes 3 segundos para colocar el mouse sobre el buscador de LDCOM.","Capturar buscador")|Out-Null;Start-Sleep -Seconds 3;$pos=[Windows.Forms.Cursor]::Position;$data.settings.targetX=$pos.X;$data.settings.targetY=$pos.Y;$data.settings.hasTarget=$true;Save-Data $data;$status2.Text="Posición guardada: $($pos.X), $($pos.Y)";$panel.Show();$f.Show()})
  $save1.Add_Click({Set-Setting "clickSearch" $chk.Checked;Set-Setting "sendEnter" $ent.Checked;[Windows.Forms.MessageBox]::Show("Configuración guardada.")|Out-Null})
  $save4.Add_Click({$data.settings.imageWidth=[int]$nums['imageWidth'].Value;$data.settings.imageHeight=[int]$nums['imageHeight'].Value;$data.settings.cardWidth=[int]$nums['cardWidth'].Value;$data.settings.cardHeight=[int]$nums['cardHeight'].Value;Save-Data $data;Refresh-View;[Windows.Forms.MessageBox]::Show("Tamaño guardado.")|Out-Null})
  [void]$f.ShowDialog($panel)
}

# ---------------- Navegación por teclado ----------------

function Handle-NavigationKey($key) {
  switch($key){
    ([Windows.Forms.Keys]::Left) { Move-CategorySelection -1; return $true }
    ([Windows.Forms.Keys]::Right) { Move-CategorySelection 1; return $true }
    ([Windows.Forms.Keys]::Up) { Move-ProductSelection -1; return $true }
    ([Windows.Forms.Keys]::Down) { Move-ProductSelection 1; return $true }
    ([Windows.Forms.Keys]::Enter) {
      if($script:productCards.Count -gt 0 -and $script:selectedProductIndex -ge 0 -and $script:selectedProductIndex -lt $script:productCards.Count){
        $p=$script:productCards[$script:selectedProductIndex].Tag
        if($p){Send-Code $p.code}
      }
      return $true
    }
  }
  return $false
}

$panel.KeyPreview=$true
$panel.Add_KeyDown({
  $active=$panel.ActiveControl
  if($active -is [Windows.Forms.TextBox] -or $active -is [Windows.Forms.ComboBox]){return}
  if(Handle-NavigationKey $_.KeyCode){$_.Handled=$true;$_.SuppressKeyPress=$true}
})
# Capture navigation at the product/category controls themselves so the arrows always work even when a card/button owns focus.
foreach($ctl in @($categoryFlow,$productPanel)){
  $ctl.Add_KeyDown({if(Handle-NavigationKey $_.KeyCode){$_.Handled=$true;$_.SuppressKeyPress=$true}})
}
# Keep the compact vertical layout fixed.
$panel.Add_Resize({
  if($panel.WindowState -eq [Windows.Forms.FormWindowState]::Minimized){return}
  $productPanel.Width=[Math]::Max(300,$main.ClientSize.Width-16)
  $productPanel.Height=[Math]::Max(200,$main.ClientSize.Height-102)
  $author.Location=New-Object Drawing.Point([Math]::Max(205,$panel.ClientSize.Width-$author.PreferredWidth-10),[Math]::Max(0,$panel.ClientSize.Height-27)); $author.BringToFront()
  Update-CategoryScroll
  if($script:selectedCategory){Show-Products $script:selectedCategory}
})

Refresh-View
[void]$panel.ShowDialog()



