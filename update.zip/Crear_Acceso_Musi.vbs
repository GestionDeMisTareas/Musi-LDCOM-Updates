Option Explicit
Dim sh, fso, app, lnk, desktop, target, iconPath
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
app = fso.GetParentFolderName(WScript.ScriptFullName)
target = fso.BuildPath(app, "Iniciar_Musi_LDCOM.vbs")
iconPath = fso.BuildPath(app, "Musi_LDCOM.ico")
desktop = sh.SpecialFolders("Desktop")
Set lnk = sh.CreateShortcut(fso.BuildPath(desktop, "Musi LDCOM.lnk"))
lnk.TargetPath = target
lnk.WorkingDirectory = app
lnk.IconLocation = iconPath & ",0"
lnk.Description = "Catálogo compacto Musi para LDCOM"
lnk.Save
MsgBox "Listo. Se creó el acceso 'Musi LDCOM' en el escritorio.", 64, "Musi LDCOM"
